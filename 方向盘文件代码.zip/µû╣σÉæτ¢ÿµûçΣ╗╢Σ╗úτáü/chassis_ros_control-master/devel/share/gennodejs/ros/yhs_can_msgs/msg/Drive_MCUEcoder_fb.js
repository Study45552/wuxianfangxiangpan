// Auto-generated. Do not edit!

// (in-package yhs_can_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class Drive_MCUEcoder_fb {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.Drive_fb_MCUEcoder = null;
    }
    else {
      if (initObj.hasOwnProperty('Drive_fb_MCUEcoder')) {
        this.Drive_fb_MCUEcoder = initObj.Drive_fb_MCUEcoder
      }
      else {
        this.Drive_fb_MCUEcoder = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Drive_MCUEcoder_fb
    // Serialize message field [Drive_fb_MCUEcoder]
    bufferOffset = _serializer.int32(obj.Drive_fb_MCUEcoder, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Drive_MCUEcoder_fb
    let len;
    let data = new Drive_MCUEcoder_fb(null);
    // Deserialize message field [Drive_fb_MCUEcoder]
    data.Drive_fb_MCUEcoder = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'yhs_can_msgs/Drive_MCUEcoder_fb';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '48c12cfe499ba073506e85df7bf8a401';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int32 Drive_fb_MCUEcoder
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Drive_MCUEcoder_fb(null);
    if (msg.Drive_fb_MCUEcoder !== undefined) {
      resolved.Drive_fb_MCUEcoder = msg.Drive_fb_MCUEcoder;
    }
    else {
      resolved.Drive_fb_MCUEcoder = 0
    }

    return resolved;
    }
};

module.exports = Drive_MCUEcoder_fb;
