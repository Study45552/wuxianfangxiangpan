// Auto-generated. Do not edit!

// (in-package yhs_can_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class ctrl_fb {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.ctrl_fb_gear = null;
      this.ctrl_fb_velocity = null;
      this.ctrl_fb_steering = null;
      this.ctrl_fb_Brake = null;
      this.ctrl_fb_mode = null;
    }
    else {
      if (initObj.hasOwnProperty('ctrl_fb_gear')) {
        this.ctrl_fb_gear = initObj.ctrl_fb_gear
      }
      else {
        this.ctrl_fb_gear = 0;
      }
      if (initObj.hasOwnProperty('ctrl_fb_velocity')) {
        this.ctrl_fb_velocity = initObj.ctrl_fb_velocity
      }
      else {
        this.ctrl_fb_velocity = 0.0;
      }
      if (initObj.hasOwnProperty('ctrl_fb_steering')) {
        this.ctrl_fb_steering = initObj.ctrl_fb_steering
      }
      else {
        this.ctrl_fb_steering = 0.0;
      }
      if (initObj.hasOwnProperty('ctrl_fb_Brake')) {
        this.ctrl_fb_Brake = initObj.ctrl_fb_Brake
      }
      else {
        this.ctrl_fb_Brake = 0;
      }
      if (initObj.hasOwnProperty('ctrl_fb_mode')) {
        this.ctrl_fb_mode = initObj.ctrl_fb_mode
      }
      else {
        this.ctrl_fb_mode = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ctrl_fb
    // Serialize message field [ctrl_fb_gear]
    bufferOffset = _serializer.uint8(obj.ctrl_fb_gear, buffer, bufferOffset);
    // Serialize message field [ctrl_fb_velocity]
    bufferOffset = _serializer.float32(obj.ctrl_fb_velocity, buffer, bufferOffset);
    // Serialize message field [ctrl_fb_steering]
    bufferOffset = _serializer.float32(obj.ctrl_fb_steering, buffer, bufferOffset);
    // Serialize message field [ctrl_fb_Brake]
    bufferOffset = _serializer.uint8(obj.ctrl_fb_Brake, buffer, bufferOffset);
    // Serialize message field [ctrl_fb_mode]
    bufferOffset = _serializer.uint8(obj.ctrl_fb_mode, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ctrl_fb
    let len;
    let data = new ctrl_fb(null);
    // Deserialize message field [ctrl_fb_gear]
    data.ctrl_fb_gear = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [ctrl_fb_velocity]
    data.ctrl_fb_velocity = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [ctrl_fb_steering]
    data.ctrl_fb_steering = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [ctrl_fb_Brake]
    data.ctrl_fb_Brake = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [ctrl_fb_mode]
    data.ctrl_fb_mode = _deserializer.uint8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 11;
  }

  static datatype() {
    // Returns string type for a message object
    return 'yhs_can_msgs/ctrl_fb';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '876fac9dcb2875032cf2f6858ba5f1fa';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint8    ctrl_fb_gear
    float32  ctrl_fb_velocity
    float32  ctrl_fb_steering
    uint8    ctrl_fb_Brake
    uint8    ctrl_fb_mode
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ctrl_fb(null);
    if (msg.ctrl_fb_gear !== undefined) {
      resolved.ctrl_fb_gear = msg.ctrl_fb_gear;
    }
    else {
      resolved.ctrl_fb_gear = 0
    }

    if (msg.ctrl_fb_velocity !== undefined) {
      resolved.ctrl_fb_velocity = msg.ctrl_fb_velocity;
    }
    else {
      resolved.ctrl_fb_velocity = 0.0
    }

    if (msg.ctrl_fb_steering !== undefined) {
      resolved.ctrl_fb_steering = msg.ctrl_fb_steering;
    }
    else {
      resolved.ctrl_fb_steering = 0.0
    }

    if (msg.ctrl_fb_Brake !== undefined) {
      resolved.ctrl_fb_Brake = msg.ctrl_fb_Brake;
    }
    else {
      resolved.ctrl_fb_Brake = 0
    }

    if (msg.ctrl_fb_mode !== undefined) {
      resolved.ctrl_fb_mode = msg.ctrl_fb_mode;
    }
    else {
      resolved.ctrl_fb_mode = 0
    }

    return resolved;
    }
};

module.exports = ctrl_fb;
