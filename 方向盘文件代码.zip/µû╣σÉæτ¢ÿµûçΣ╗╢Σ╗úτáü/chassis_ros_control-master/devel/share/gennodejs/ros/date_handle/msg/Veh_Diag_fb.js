// Auto-generated. Do not edit!

// (in-package date_handle.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class Veh_Diag_fb {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.Veh_fb_FaultLevel = null;
      this.Veh_fb_AutoCANCtrlCmd = null;
      this.Veh_fb_AutoIOCANCmd = null;
      this.Veh_fb_EPSDisOnline = null;
      this.Veh_fb_EPSfault = null;
      this.Veh_fb_EPSMosfetOT = null;
      this.Veh_fb_EPSWarning = null;
      this.Veh_fb_EPSDisWork = null;
      this.Veh_fb_EPSOverCurrent = null;
      this.Veh_fb_STReserve = null;
      this.Veh_fb_EHBecuFault = null;
      this.Veh_fb_EHBDisOnline = null;
      this.Veh_fb_EHBWorkModelFault = null;
      this.Veh_fb_EHBDisEn = null;
      this.Veh_fb_EHBAnguleFault = null;
      this.Veh_fb_EHBOT = null;
      this.Veh_fb_EHBPowerFault = null;
      this.Veh_fb_EHBsensorAbnomal = null;
      this.Veh_fb_EHBMotorFault = null;
      this.Veh_fb_EHBOilPressSensorFault = null;
      this.Veh_fb_EHBOilFault = null;
      this.Veh_fb_BraReserve = null;
      this.Veh_fb_DrvMCUDisOnline = null;
      this.Veh_fb_DrvMCUOT = null;
      this.Veh_fb_DrvMCUOV = null;
      this.Veh_fb_DrvMCUUV = null;
      this.Veh_fb_DrvMCUShort = null;
      this.Veh_fb_DrvMCUScram = null;
      this.Veh_fb_DrvMCUHall = null;
      this.Veh_fb_DrvMCUMOSFEF = null;
      this.Veh_fb_DrvReserve = null;
      this.Veh_fb_AUXBMSDisOnline = null;
      this.Veh_fb_AuxScram = null;
      this.Veh_fb_AuxRemoteClose = null;
      this.Veh_fb_AuxRemoteDisOnline = null;
      this.Veh_fb_AuxReserve = null;
    }
    else {
      if (initObj.hasOwnProperty('Veh_fb_FaultLevel')) {
        this.Veh_fb_FaultLevel = initObj.Veh_fb_FaultLevel
      }
      else {
        this.Veh_fb_FaultLevel = 0;
      }
      if (initObj.hasOwnProperty('Veh_fb_AutoCANCtrlCmd')) {
        this.Veh_fb_AutoCANCtrlCmd = initObj.Veh_fb_AutoCANCtrlCmd
      }
      else {
        this.Veh_fb_AutoCANCtrlCmd = false;
      }
      if (initObj.hasOwnProperty('Veh_fb_AutoIOCANCmd')) {
        this.Veh_fb_AutoIOCANCmd = initObj.Veh_fb_AutoIOCANCmd
      }
      else {
        this.Veh_fb_AutoIOCANCmd = false;
      }
      if (initObj.hasOwnProperty('Veh_fb_EPSDisOnline')) {
        this.Veh_fb_EPSDisOnline = initObj.Veh_fb_EPSDisOnline
      }
      else {
        this.Veh_fb_EPSDisOnline = false;
      }
      if (initObj.hasOwnProperty('Veh_fb_EPSfault')) {
        this.Veh_fb_EPSfault = initObj.Veh_fb_EPSfault
      }
      else {
        this.Veh_fb_EPSfault = false;
      }
      if (initObj.hasOwnProperty('Veh_fb_EPSMosfetOT')) {
        this.Veh_fb_EPSMosfetOT = initObj.Veh_fb_EPSMosfetOT
      }
      else {
        this.Veh_fb_EPSMosfetOT = false;
      }
      if (initObj.hasOwnProperty('Veh_fb_EPSWarning')) {
        this.Veh_fb_EPSWarning = initObj.Veh_fb_EPSWarning
      }
      else {
        this.Veh_fb_EPSWarning = false;
      }
      if (initObj.hasOwnProperty('Veh_fb_EPSDisWork')) {
        this.Veh_fb_EPSDisWork = initObj.Veh_fb_EPSDisWork
      }
      else {
        this.Veh_fb_EPSDisWork = false;
      }
      if (initObj.hasOwnProperty('Veh_fb_EPSOverCurrent')) {
        this.Veh_fb_EPSOverCurrent = initObj.Veh_fb_EPSOverCurrent
      }
      else {
        this.Veh_fb_EPSOverCurrent = false;
      }
      if (initObj.hasOwnProperty('Veh_fb_STReserve')) {
        this.Veh_fb_STReserve = initObj.Veh_fb_STReserve
      }
      else {
        this.Veh_fb_STReserve = false;
      }
      if (initObj.hasOwnProperty('Veh_fb_EHBecuFault')) {
        this.Veh_fb_EHBecuFault = initObj.Veh_fb_EHBecuFault
      }
      else {
        this.Veh_fb_EHBecuFault = false;
      }
      if (initObj.hasOwnProperty('Veh_fb_EHBDisOnline')) {
        this.Veh_fb_EHBDisOnline = initObj.Veh_fb_EHBDisOnline
      }
      else {
        this.Veh_fb_EHBDisOnline = false;
      }
      if (initObj.hasOwnProperty('Veh_fb_EHBWorkModelFault')) {
        this.Veh_fb_EHBWorkModelFault = initObj.Veh_fb_EHBWorkModelFault
      }
      else {
        this.Veh_fb_EHBWorkModelFault = false;
      }
      if (initObj.hasOwnProperty('Veh_fb_EHBDisEn')) {
        this.Veh_fb_EHBDisEn = initObj.Veh_fb_EHBDisEn
      }
      else {
        this.Veh_fb_EHBDisEn = false;
      }
      if (initObj.hasOwnProperty('Veh_fb_EHBAnguleFault')) {
        this.Veh_fb_EHBAnguleFault = initObj.Veh_fb_EHBAnguleFault
      }
      else {
        this.Veh_fb_EHBAnguleFault = false;
      }
      if (initObj.hasOwnProperty('Veh_fb_EHBOT')) {
        this.Veh_fb_EHBOT = initObj.Veh_fb_EHBOT
      }
      else {
        this.Veh_fb_EHBOT = false;
      }
      if (initObj.hasOwnProperty('Veh_fb_EHBPowerFault')) {
        this.Veh_fb_EHBPowerFault = initObj.Veh_fb_EHBPowerFault
      }
      else {
        this.Veh_fb_EHBPowerFault = false;
      }
      if (initObj.hasOwnProperty('Veh_fb_EHBsensorAbnomal')) {
        this.Veh_fb_EHBsensorAbnomal = initObj.Veh_fb_EHBsensorAbnomal
      }
      else {
        this.Veh_fb_EHBsensorAbnomal = false;
      }
      if (initObj.hasOwnProperty('Veh_fb_EHBMotorFault')) {
        this.Veh_fb_EHBMotorFault = initObj.Veh_fb_EHBMotorFault
      }
      else {
        this.Veh_fb_EHBMotorFault = false;
      }
      if (initObj.hasOwnProperty('Veh_fb_EHBOilPressSensorFault')) {
        this.Veh_fb_EHBOilPressSensorFault = initObj.Veh_fb_EHBOilPressSensorFault
      }
      else {
        this.Veh_fb_EHBOilPressSensorFault = false;
      }
      if (initObj.hasOwnProperty('Veh_fb_EHBOilFault')) {
        this.Veh_fb_EHBOilFault = initObj.Veh_fb_EHBOilFault
      }
      else {
        this.Veh_fb_EHBOilFault = false;
      }
      if (initObj.hasOwnProperty('Veh_fb_BraReserve')) {
        this.Veh_fb_BraReserve = initObj.Veh_fb_BraReserve
      }
      else {
        this.Veh_fb_BraReserve = false;
      }
      if (initObj.hasOwnProperty('Veh_fb_DrvMCUDisOnline')) {
        this.Veh_fb_DrvMCUDisOnline = initObj.Veh_fb_DrvMCUDisOnline
      }
      else {
        this.Veh_fb_DrvMCUDisOnline = false;
      }
      if (initObj.hasOwnProperty('Veh_fb_DrvMCUOT')) {
        this.Veh_fb_DrvMCUOT = initObj.Veh_fb_DrvMCUOT
      }
      else {
        this.Veh_fb_DrvMCUOT = false;
      }
      if (initObj.hasOwnProperty('Veh_fb_DrvMCUOV')) {
        this.Veh_fb_DrvMCUOV = initObj.Veh_fb_DrvMCUOV
      }
      else {
        this.Veh_fb_DrvMCUOV = false;
      }
      if (initObj.hasOwnProperty('Veh_fb_DrvMCUUV')) {
        this.Veh_fb_DrvMCUUV = initObj.Veh_fb_DrvMCUUV
      }
      else {
        this.Veh_fb_DrvMCUUV = false;
      }
      if (initObj.hasOwnProperty('Veh_fb_DrvMCUShort')) {
        this.Veh_fb_DrvMCUShort = initObj.Veh_fb_DrvMCUShort
      }
      else {
        this.Veh_fb_DrvMCUShort = false;
      }
      if (initObj.hasOwnProperty('Veh_fb_DrvMCUScram')) {
        this.Veh_fb_DrvMCUScram = initObj.Veh_fb_DrvMCUScram
      }
      else {
        this.Veh_fb_DrvMCUScram = false;
      }
      if (initObj.hasOwnProperty('Veh_fb_DrvMCUHall')) {
        this.Veh_fb_DrvMCUHall = initObj.Veh_fb_DrvMCUHall
      }
      else {
        this.Veh_fb_DrvMCUHall = false;
      }
      if (initObj.hasOwnProperty('Veh_fb_DrvMCUMOSFEF')) {
        this.Veh_fb_DrvMCUMOSFEF = initObj.Veh_fb_DrvMCUMOSFEF
      }
      else {
        this.Veh_fb_DrvMCUMOSFEF = false;
      }
      if (initObj.hasOwnProperty('Veh_fb_DrvReserve')) {
        this.Veh_fb_DrvReserve = initObj.Veh_fb_DrvReserve
      }
      else {
        this.Veh_fb_DrvReserve = false;
      }
      if (initObj.hasOwnProperty('Veh_fb_AUXBMSDisOnline')) {
        this.Veh_fb_AUXBMSDisOnline = initObj.Veh_fb_AUXBMSDisOnline
      }
      else {
        this.Veh_fb_AUXBMSDisOnline = false;
      }
      if (initObj.hasOwnProperty('Veh_fb_AuxScram')) {
        this.Veh_fb_AuxScram = initObj.Veh_fb_AuxScram
      }
      else {
        this.Veh_fb_AuxScram = false;
      }
      if (initObj.hasOwnProperty('Veh_fb_AuxRemoteClose')) {
        this.Veh_fb_AuxRemoteClose = initObj.Veh_fb_AuxRemoteClose
      }
      else {
        this.Veh_fb_AuxRemoteClose = false;
      }
      if (initObj.hasOwnProperty('Veh_fb_AuxRemoteDisOnline')) {
        this.Veh_fb_AuxRemoteDisOnline = initObj.Veh_fb_AuxRemoteDisOnline
      }
      else {
        this.Veh_fb_AuxRemoteDisOnline = false;
      }
      if (initObj.hasOwnProperty('Veh_fb_AuxReserve')) {
        this.Veh_fb_AuxReserve = initObj.Veh_fb_AuxReserve
      }
      else {
        this.Veh_fb_AuxReserve = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Veh_Diag_fb
    // Serialize message field [Veh_fb_FaultLevel]
    bufferOffset = _serializer.uint8(obj.Veh_fb_FaultLevel, buffer, bufferOffset);
    // Serialize message field [Veh_fb_AutoCANCtrlCmd]
    bufferOffset = _serializer.bool(obj.Veh_fb_AutoCANCtrlCmd, buffer, bufferOffset);
    // Serialize message field [Veh_fb_AutoIOCANCmd]
    bufferOffset = _serializer.bool(obj.Veh_fb_AutoIOCANCmd, buffer, bufferOffset);
    // Serialize message field [Veh_fb_EPSDisOnline]
    bufferOffset = _serializer.bool(obj.Veh_fb_EPSDisOnline, buffer, bufferOffset);
    // Serialize message field [Veh_fb_EPSfault]
    bufferOffset = _serializer.bool(obj.Veh_fb_EPSfault, buffer, bufferOffset);
    // Serialize message field [Veh_fb_EPSMosfetOT]
    bufferOffset = _serializer.bool(obj.Veh_fb_EPSMosfetOT, buffer, bufferOffset);
    // Serialize message field [Veh_fb_EPSWarning]
    bufferOffset = _serializer.bool(obj.Veh_fb_EPSWarning, buffer, bufferOffset);
    // Serialize message field [Veh_fb_EPSDisWork]
    bufferOffset = _serializer.bool(obj.Veh_fb_EPSDisWork, buffer, bufferOffset);
    // Serialize message field [Veh_fb_EPSOverCurrent]
    bufferOffset = _serializer.bool(obj.Veh_fb_EPSOverCurrent, buffer, bufferOffset);
    // Serialize message field [Veh_fb_STReserve]
    bufferOffset = _serializer.bool(obj.Veh_fb_STReserve, buffer, bufferOffset);
    // Serialize message field [Veh_fb_EHBecuFault]
    bufferOffset = _serializer.bool(obj.Veh_fb_EHBecuFault, buffer, bufferOffset);
    // Serialize message field [Veh_fb_EHBDisOnline]
    bufferOffset = _serializer.bool(obj.Veh_fb_EHBDisOnline, buffer, bufferOffset);
    // Serialize message field [Veh_fb_EHBWorkModelFault]
    bufferOffset = _serializer.bool(obj.Veh_fb_EHBWorkModelFault, buffer, bufferOffset);
    // Serialize message field [Veh_fb_EHBDisEn]
    bufferOffset = _serializer.bool(obj.Veh_fb_EHBDisEn, buffer, bufferOffset);
    // Serialize message field [Veh_fb_EHBAnguleFault]
    bufferOffset = _serializer.bool(obj.Veh_fb_EHBAnguleFault, buffer, bufferOffset);
    // Serialize message field [Veh_fb_EHBOT]
    bufferOffset = _serializer.bool(obj.Veh_fb_EHBOT, buffer, bufferOffset);
    // Serialize message field [Veh_fb_EHBPowerFault]
    bufferOffset = _serializer.bool(obj.Veh_fb_EHBPowerFault, buffer, bufferOffset);
    // Serialize message field [Veh_fb_EHBsensorAbnomal]
    bufferOffset = _serializer.bool(obj.Veh_fb_EHBsensorAbnomal, buffer, bufferOffset);
    // Serialize message field [Veh_fb_EHBMotorFault]
    bufferOffset = _serializer.bool(obj.Veh_fb_EHBMotorFault, buffer, bufferOffset);
    // Serialize message field [Veh_fb_EHBOilPressSensorFault]
    bufferOffset = _serializer.bool(obj.Veh_fb_EHBOilPressSensorFault, buffer, bufferOffset);
    // Serialize message field [Veh_fb_EHBOilFault]
    bufferOffset = _serializer.bool(obj.Veh_fb_EHBOilFault, buffer, bufferOffset);
    // Serialize message field [Veh_fb_BraReserve]
    bufferOffset = _serializer.bool(obj.Veh_fb_BraReserve, buffer, bufferOffset);
    // Serialize message field [Veh_fb_DrvMCUDisOnline]
    bufferOffset = _serializer.bool(obj.Veh_fb_DrvMCUDisOnline, buffer, bufferOffset);
    // Serialize message field [Veh_fb_DrvMCUOT]
    bufferOffset = _serializer.bool(obj.Veh_fb_DrvMCUOT, buffer, bufferOffset);
    // Serialize message field [Veh_fb_DrvMCUOV]
    bufferOffset = _serializer.bool(obj.Veh_fb_DrvMCUOV, buffer, bufferOffset);
    // Serialize message field [Veh_fb_DrvMCUUV]
    bufferOffset = _serializer.bool(obj.Veh_fb_DrvMCUUV, buffer, bufferOffset);
    // Serialize message field [Veh_fb_DrvMCUShort]
    bufferOffset = _serializer.bool(obj.Veh_fb_DrvMCUShort, buffer, bufferOffset);
    // Serialize message field [Veh_fb_DrvMCUScram]
    bufferOffset = _serializer.bool(obj.Veh_fb_DrvMCUScram, buffer, bufferOffset);
    // Serialize message field [Veh_fb_DrvMCUHall]
    bufferOffset = _serializer.bool(obj.Veh_fb_DrvMCUHall, buffer, bufferOffset);
    // Serialize message field [Veh_fb_DrvMCUMOSFEF]
    bufferOffset = _serializer.bool(obj.Veh_fb_DrvMCUMOSFEF, buffer, bufferOffset);
    // Serialize message field [Veh_fb_DrvReserve]
    bufferOffset = _serializer.bool(obj.Veh_fb_DrvReserve, buffer, bufferOffset);
    // Serialize message field [Veh_fb_AUXBMSDisOnline]
    bufferOffset = _serializer.bool(obj.Veh_fb_AUXBMSDisOnline, buffer, bufferOffset);
    // Serialize message field [Veh_fb_AuxScram]
    bufferOffset = _serializer.bool(obj.Veh_fb_AuxScram, buffer, bufferOffset);
    // Serialize message field [Veh_fb_AuxRemoteClose]
    bufferOffset = _serializer.bool(obj.Veh_fb_AuxRemoteClose, buffer, bufferOffset);
    // Serialize message field [Veh_fb_AuxRemoteDisOnline]
    bufferOffset = _serializer.bool(obj.Veh_fb_AuxRemoteDisOnline, buffer, bufferOffset);
    // Serialize message field [Veh_fb_AuxReserve]
    bufferOffset = _serializer.bool(obj.Veh_fb_AuxReserve, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Veh_Diag_fb
    let len;
    let data = new Veh_Diag_fb(null);
    // Deserialize message field [Veh_fb_FaultLevel]
    data.Veh_fb_FaultLevel = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [Veh_fb_AutoCANCtrlCmd]
    data.Veh_fb_AutoCANCtrlCmd = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [Veh_fb_AutoIOCANCmd]
    data.Veh_fb_AutoIOCANCmd = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [Veh_fb_EPSDisOnline]
    data.Veh_fb_EPSDisOnline = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [Veh_fb_EPSfault]
    data.Veh_fb_EPSfault = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [Veh_fb_EPSMosfetOT]
    data.Veh_fb_EPSMosfetOT = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [Veh_fb_EPSWarning]
    data.Veh_fb_EPSWarning = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [Veh_fb_EPSDisWork]
    data.Veh_fb_EPSDisWork = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [Veh_fb_EPSOverCurrent]
    data.Veh_fb_EPSOverCurrent = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [Veh_fb_STReserve]
    data.Veh_fb_STReserve = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [Veh_fb_EHBecuFault]
    data.Veh_fb_EHBecuFault = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [Veh_fb_EHBDisOnline]
    data.Veh_fb_EHBDisOnline = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [Veh_fb_EHBWorkModelFault]
    data.Veh_fb_EHBWorkModelFault = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [Veh_fb_EHBDisEn]
    data.Veh_fb_EHBDisEn = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [Veh_fb_EHBAnguleFault]
    data.Veh_fb_EHBAnguleFault = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [Veh_fb_EHBOT]
    data.Veh_fb_EHBOT = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [Veh_fb_EHBPowerFault]
    data.Veh_fb_EHBPowerFault = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [Veh_fb_EHBsensorAbnomal]
    data.Veh_fb_EHBsensorAbnomal = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [Veh_fb_EHBMotorFault]
    data.Veh_fb_EHBMotorFault = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [Veh_fb_EHBOilPressSensorFault]
    data.Veh_fb_EHBOilPressSensorFault = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [Veh_fb_EHBOilFault]
    data.Veh_fb_EHBOilFault = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [Veh_fb_BraReserve]
    data.Veh_fb_BraReserve = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [Veh_fb_DrvMCUDisOnline]
    data.Veh_fb_DrvMCUDisOnline = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [Veh_fb_DrvMCUOT]
    data.Veh_fb_DrvMCUOT = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [Veh_fb_DrvMCUOV]
    data.Veh_fb_DrvMCUOV = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [Veh_fb_DrvMCUUV]
    data.Veh_fb_DrvMCUUV = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [Veh_fb_DrvMCUShort]
    data.Veh_fb_DrvMCUShort = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [Veh_fb_DrvMCUScram]
    data.Veh_fb_DrvMCUScram = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [Veh_fb_DrvMCUHall]
    data.Veh_fb_DrvMCUHall = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [Veh_fb_DrvMCUMOSFEF]
    data.Veh_fb_DrvMCUMOSFEF = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [Veh_fb_DrvReserve]
    data.Veh_fb_DrvReserve = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [Veh_fb_AUXBMSDisOnline]
    data.Veh_fb_AUXBMSDisOnline = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [Veh_fb_AuxScram]
    data.Veh_fb_AuxScram = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [Veh_fb_AuxRemoteClose]
    data.Veh_fb_AuxRemoteClose = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [Veh_fb_AuxRemoteDisOnline]
    data.Veh_fb_AuxRemoteDisOnline = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [Veh_fb_AuxReserve]
    data.Veh_fb_AuxReserve = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 36;
  }

  static datatype() {
    // Returns string type for a message object
    return 'date_handle/Veh_Diag_fb';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'ad9f4ebd1a52940a4c31220f7eec0424';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint8 Veh_fb_FaultLevel
    bool Veh_fb_AutoCANCtrlCmd
    bool Veh_fb_AutoIOCANCmd
    
    bool Veh_fb_EPSDisOnline
    bool Veh_fb_EPSfault
    
    bool Veh_fb_EPSMosfetOT
    
    bool Veh_fb_EPSWarning
    
    bool Veh_fb_EPSDisWork
    
    bool Veh_fb_EPSOverCurrent
    
    bool Veh_fb_STReserve
    
    bool Veh_fb_EHBecuFault
    
    bool Veh_fb_EHBDisOnline
    
    bool Veh_fb_EHBWorkModelFault
    
    bool Veh_fb_EHBDisEn
    
    bool Veh_fb_EHBAnguleFault
    
    bool Veh_fb_EHBOT
    
    bool Veh_fb_EHBPowerFault
    
    bool Veh_fb_EHBsensorAbnomal
    
    bool Veh_fb_EHBMotorFault
    
    bool Veh_fb_EHBOilPressSensorFault
    
    bool Veh_fb_EHBOilFault
    
    bool Veh_fb_BraReserve
    
    bool Veh_fb_DrvMCUDisOnline
    
    bool Veh_fb_DrvMCUOT
    
    bool Veh_fb_DrvMCUOV
    
    bool Veh_fb_DrvMCUUV
    
    bool Veh_fb_DrvMCUShort
    
    bool Veh_fb_DrvMCUScram
    
    bool Veh_fb_DrvMCUHall
    
    bool Veh_fb_DrvMCUMOSFEF
    
    bool Veh_fb_DrvReserve
    
    bool Veh_fb_AUXBMSDisOnline
    
    bool Veh_fb_AuxScram
    
    bool Veh_fb_AuxRemoteClose
    
    bool Veh_fb_AuxRemoteDisOnline
    
    bool Veh_fb_AuxReserve
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Veh_Diag_fb(null);
    if (msg.Veh_fb_FaultLevel !== undefined) {
      resolved.Veh_fb_FaultLevel = msg.Veh_fb_FaultLevel;
    }
    else {
      resolved.Veh_fb_FaultLevel = 0
    }

    if (msg.Veh_fb_AutoCANCtrlCmd !== undefined) {
      resolved.Veh_fb_AutoCANCtrlCmd = msg.Veh_fb_AutoCANCtrlCmd;
    }
    else {
      resolved.Veh_fb_AutoCANCtrlCmd = false
    }

    if (msg.Veh_fb_AutoIOCANCmd !== undefined) {
      resolved.Veh_fb_AutoIOCANCmd = msg.Veh_fb_AutoIOCANCmd;
    }
    else {
      resolved.Veh_fb_AutoIOCANCmd = false
    }

    if (msg.Veh_fb_EPSDisOnline !== undefined) {
      resolved.Veh_fb_EPSDisOnline = msg.Veh_fb_EPSDisOnline;
    }
    else {
      resolved.Veh_fb_EPSDisOnline = false
    }

    if (msg.Veh_fb_EPSfault !== undefined) {
      resolved.Veh_fb_EPSfault = msg.Veh_fb_EPSfault;
    }
    else {
      resolved.Veh_fb_EPSfault = false
    }

    if (msg.Veh_fb_EPSMosfetOT !== undefined) {
      resolved.Veh_fb_EPSMosfetOT = msg.Veh_fb_EPSMosfetOT;
    }
    else {
      resolved.Veh_fb_EPSMosfetOT = false
    }

    if (msg.Veh_fb_EPSWarning !== undefined) {
      resolved.Veh_fb_EPSWarning = msg.Veh_fb_EPSWarning;
    }
    else {
      resolved.Veh_fb_EPSWarning = false
    }

    if (msg.Veh_fb_EPSDisWork !== undefined) {
      resolved.Veh_fb_EPSDisWork = msg.Veh_fb_EPSDisWork;
    }
    else {
      resolved.Veh_fb_EPSDisWork = false
    }

    if (msg.Veh_fb_EPSOverCurrent !== undefined) {
      resolved.Veh_fb_EPSOverCurrent = msg.Veh_fb_EPSOverCurrent;
    }
    else {
      resolved.Veh_fb_EPSOverCurrent = false
    }

    if (msg.Veh_fb_STReserve !== undefined) {
      resolved.Veh_fb_STReserve = msg.Veh_fb_STReserve;
    }
    else {
      resolved.Veh_fb_STReserve = false
    }

    if (msg.Veh_fb_EHBecuFault !== undefined) {
      resolved.Veh_fb_EHBecuFault = msg.Veh_fb_EHBecuFault;
    }
    else {
      resolved.Veh_fb_EHBecuFault = false
    }

    if (msg.Veh_fb_EHBDisOnline !== undefined) {
      resolved.Veh_fb_EHBDisOnline = msg.Veh_fb_EHBDisOnline;
    }
    else {
      resolved.Veh_fb_EHBDisOnline = false
    }

    if (msg.Veh_fb_EHBWorkModelFault !== undefined) {
      resolved.Veh_fb_EHBWorkModelFault = msg.Veh_fb_EHBWorkModelFault;
    }
    else {
      resolved.Veh_fb_EHBWorkModelFault = false
    }

    if (msg.Veh_fb_EHBDisEn !== undefined) {
      resolved.Veh_fb_EHBDisEn = msg.Veh_fb_EHBDisEn;
    }
    else {
      resolved.Veh_fb_EHBDisEn = false
    }

    if (msg.Veh_fb_EHBAnguleFault !== undefined) {
      resolved.Veh_fb_EHBAnguleFault = msg.Veh_fb_EHBAnguleFault;
    }
    else {
      resolved.Veh_fb_EHBAnguleFault = false
    }

    if (msg.Veh_fb_EHBOT !== undefined) {
      resolved.Veh_fb_EHBOT = msg.Veh_fb_EHBOT;
    }
    else {
      resolved.Veh_fb_EHBOT = false
    }

    if (msg.Veh_fb_EHBPowerFault !== undefined) {
      resolved.Veh_fb_EHBPowerFault = msg.Veh_fb_EHBPowerFault;
    }
    else {
      resolved.Veh_fb_EHBPowerFault = false
    }

    if (msg.Veh_fb_EHBsensorAbnomal !== undefined) {
      resolved.Veh_fb_EHBsensorAbnomal = msg.Veh_fb_EHBsensorAbnomal;
    }
    else {
      resolved.Veh_fb_EHBsensorAbnomal = false
    }

    if (msg.Veh_fb_EHBMotorFault !== undefined) {
      resolved.Veh_fb_EHBMotorFault = msg.Veh_fb_EHBMotorFault;
    }
    else {
      resolved.Veh_fb_EHBMotorFault = false
    }

    if (msg.Veh_fb_EHBOilPressSensorFault !== undefined) {
      resolved.Veh_fb_EHBOilPressSensorFault = msg.Veh_fb_EHBOilPressSensorFault;
    }
    else {
      resolved.Veh_fb_EHBOilPressSensorFault = false
    }

    if (msg.Veh_fb_EHBOilFault !== undefined) {
      resolved.Veh_fb_EHBOilFault = msg.Veh_fb_EHBOilFault;
    }
    else {
      resolved.Veh_fb_EHBOilFault = false
    }

    if (msg.Veh_fb_BraReserve !== undefined) {
      resolved.Veh_fb_BraReserve = msg.Veh_fb_BraReserve;
    }
    else {
      resolved.Veh_fb_BraReserve = false
    }

    if (msg.Veh_fb_DrvMCUDisOnline !== undefined) {
      resolved.Veh_fb_DrvMCUDisOnline = msg.Veh_fb_DrvMCUDisOnline;
    }
    else {
      resolved.Veh_fb_DrvMCUDisOnline = false
    }

    if (msg.Veh_fb_DrvMCUOT !== undefined) {
      resolved.Veh_fb_DrvMCUOT = msg.Veh_fb_DrvMCUOT;
    }
    else {
      resolved.Veh_fb_DrvMCUOT = false
    }

    if (msg.Veh_fb_DrvMCUOV !== undefined) {
      resolved.Veh_fb_DrvMCUOV = msg.Veh_fb_DrvMCUOV;
    }
    else {
      resolved.Veh_fb_DrvMCUOV = false
    }

    if (msg.Veh_fb_DrvMCUUV !== undefined) {
      resolved.Veh_fb_DrvMCUUV = msg.Veh_fb_DrvMCUUV;
    }
    else {
      resolved.Veh_fb_DrvMCUUV = false
    }

    if (msg.Veh_fb_DrvMCUShort !== undefined) {
      resolved.Veh_fb_DrvMCUShort = msg.Veh_fb_DrvMCUShort;
    }
    else {
      resolved.Veh_fb_DrvMCUShort = false
    }

    if (msg.Veh_fb_DrvMCUScram !== undefined) {
      resolved.Veh_fb_DrvMCUScram = msg.Veh_fb_DrvMCUScram;
    }
    else {
      resolved.Veh_fb_DrvMCUScram = false
    }

    if (msg.Veh_fb_DrvMCUHall !== undefined) {
      resolved.Veh_fb_DrvMCUHall = msg.Veh_fb_DrvMCUHall;
    }
    else {
      resolved.Veh_fb_DrvMCUHall = false
    }

    if (msg.Veh_fb_DrvMCUMOSFEF !== undefined) {
      resolved.Veh_fb_DrvMCUMOSFEF = msg.Veh_fb_DrvMCUMOSFEF;
    }
    else {
      resolved.Veh_fb_DrvMCUMOSFEF = false
    }

    if (msg.Veh_fb_DrvReserve !== undefined) {
      resolved.Veh_fb_DrvReserve = msg.Veh_fb_DrvReserve;
    }
    else {
      resolved.Veh_fb_DrvReserve = false
    }

    if (msg.Veh_fb_AUXBMSDisOnline !== undefined) {
      resolved.Veh_fb_AUXBMSDisOnline = msg.Veh_fb_AUXBMSDisOnline;
    }
    else {
      resolved.Veh_fb_AUXBMSDisOnline = false
    }

    if (msg.Veh_fb_AuxScram !== undefined) {
      resolved.Veh_fb_AuxScram = msg.Veh_fb_AuxScram;
    }
    else {
      resolved.Veh_fb_AuxScram = false
    }

    if (msg.Veh_fb_AuxRemoteClose !== undefined) {
      resolved.Veh_fb_AuxRemoteClose = msg.Veh_fb_AuxRemoteClose;
    }
    else {
      resolved.Veh_fb_AuxRemoteClose = false
    }

    if (msg.Veh_fb_AuxRemoteDisOnline !== undefined) {
      resolved.Veh_fb_AuxRemoteDisOnline = msg.Veh_fb_AuxRemoteDisOnline;
    }
    else {
      resolved.Veh_fb_AuxRemoteDisOnline = false
    }

    if (msg.Veh_fb_AuxReserve !== undefined) {
      resolved.Veh_fb_AuxReserve = msg.Veh_fb_AuxReserve;
    }
    else {
      resolved.Veh_fb_AuxReserve = false
    }

    return resolved;
    }
};

module.exports = Veh_Diag_fb;
