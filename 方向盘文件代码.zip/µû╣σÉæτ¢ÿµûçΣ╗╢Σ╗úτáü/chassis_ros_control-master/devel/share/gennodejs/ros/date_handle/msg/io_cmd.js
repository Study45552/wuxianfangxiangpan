// Auto-generated. Do not edit!

// (in-package date_handle.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class io_cmd {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.io_cmd_enable = null;
      this.io_cmd_upper_beam_headlamp = null;
      this.io_cmd_turn_lamp = null;
      this.io_cmd_speaker = null;
    }
    else {
      if (initObj.hasOwnProperty('io_cmd_enable')) {
        this.io_cmd_enable = initObj.io_cmd_enable
      }
      else {
        this.io_cmd_enable = false;
      }
      if (initObj.hasOwnProperty('io_cmd_upper_beam_headlamp')) {
        this.io_cmd_upper_beam_headlamp = initObj.io_cmd_upper_beam_headlamp
      }
      else {
        this.io_cmd_upper_beam_headlamp = false;
      }
      if (initObj.hasOwnProperty('io_cmd_turn_lamp')) {
        this.io_cmd_turn_lamp = initObj.io_cmd_turn_lamp
      }
      else {
        this.io_cmd_turn_lamp = 0;
      }
      if (initObj.hasOwnProperty('io_cmd_speaker')) {
        this.io_cmd_speaker = initObj.io_cmd_speaker
      }
      else {
        this.io_cmd_speaker = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type io_cmd
    // Serialize message field [io_cmd_enable]
    bufferOffset = _serializer.bool(obj.io_cmd_enable, buffer, bufferOffset);
    // Serialize message field [io_cmd_upper_beam_headlamp]
    bufferOffset = _serializer.bool(obj.io_cmd_upper_beam_headlamp, buffer, bufferOffset);
    // Serialize message field [io_cmd_turn_lamp]
    bufferOffset = _serializer.uint8(obj.io_cmd_turn_lamp, buffer, bufferOffset);
    // Serialize message field [io_cmd_speaker]
    bufferOffset = _serializer.bool(obj.io_cmd_speaker, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type io_cmd
    let len;
    let data = new io_cmd(null);
    // Deserialize message field [io_cmd_enable]
    data.io_cmd_enable = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [io_cmd_upper_beam_headlamp]
    data.io_cmd_upper_beam_headlamp = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [io_cmd_turn_lamp]
    data.io_cmd_turn_lamp = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [io_cmd_speaker]
    data.io_cmd_speaker = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'date_handle/io_cmd';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'e3863e36a9e91d857f6ff6d329c8c283';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool	 io_cmd_enable
    bool	 io_cmd_upper_beam_headlamp
    uint8	 io_cmd_turn_lamp
    bool	 io_cmd_speaker
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new io_cmd(null);
    if (msg.io_cmd_enable !== undefined) {
      resolved.io_cmd_enable = msg.io_cmd_enable;
    }
    else {
      resolved.io_cmd_enable = false
    }

    if (msg.io_cmd_upper_beam_headlamp !== undefined) {
      resolved.io_cmd_upper_beam_headlamp = msg.io_cmd_upper_beam_headlamp;
    }
    else {
      resolved.io_cmd_upper_beam_headlamp = false
    }

    if (msg.io_cmd_turn_lamp !== undefined) {
      resolved.io_cmd_turn_lamp = msg.io_cmd_turn_lamp;
    }
    else {
      resolved.io_cmd_turn_lamp = 0
    }

    if (msg.io_cmd_speaker !== undefined) {
      resolved.io_cmd_speaker = msg.io_cmd_speaker;
    }
    else {
      resolved.io_cmd_speaker = false
    }

    return resolved;
    }
};

module.exports = io_cmd;
