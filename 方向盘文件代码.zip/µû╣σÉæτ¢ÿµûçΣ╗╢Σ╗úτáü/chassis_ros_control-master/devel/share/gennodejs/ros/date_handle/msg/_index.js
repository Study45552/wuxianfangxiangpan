
"use strict";

let bms_flag_Infor_fb = require('./bms_flag_Infor_fb.js');
let odo_fb = require('./odo_fb.js');
let lr_wheel_fb = require('./lr_wheel_fb.js');
let io_fb = require('./io_fb.js');
let Veh_Diag_fb = require('./Veh_Diag_fb.js');
let Drive_MCUEcoder_fb = require('./Drive_MCUEcoder_fb.js');
let ctrl_fb = require('./ctrl_fb.js');
let io_cmd = require('./io_cmd.js');
let rr_wheel_fb = require('./rr_wheel_fb.js');
let ctrl_cmd = require('./ctrl_cmd.js');
let bms_Infor_fb = require('./bms_Infor_fb.js');

module.exports = {
  bms_flag_Infor_fb: bms_flag_Infor_fb,
  odo_fb: odo_fb,
  lr_wheel_fb: lr_wheel_fb,
  io_fb: io_fb,
  Veh_Diag_fb: Veh_Diag_fb,
  Drive_MCUEcoder_fb: Drive_MCUEcoder_fb,
  ctrl_fb: ctrl_fb,
  io_cmd: io_cmd,
  rr_wheel_fb: rr_wheel_fb,
  ctrl_cmd: ctrl_cmd,
  bms_Infor_fb: bms_Infor_fb,
};
