// Auto-generated. Do not edit!

// (in-package date_handle.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class odo_fb {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.odo_fb_accumulative_mileage = null;
      this.odo_fb_accumulative_angular = null;
    }
    else {
      if (initObj.hasOwnProperty('odo_fb_accumulative_mileage')) {
        this.odo_fb_accumulative_mileage = initObj.odo_fb_accumulative_mileage
      }
      else {
        this.odo_fb_accumulative_mileage = 0.0;
      }
      if (initObj.hasOwnProperty('odo_fb_accumulative_angular')) {
        this.odo_fb_accumulative_angular = initObj.odo_fb_accumulative_angular
      }
      else {
        this.odo_fb_accumulative_angular = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type odo_fb
    // Serialize message field [odo_fb_accumulative_mileage]
    bufferOffset = _serializer.float32(obj.odo_fb_accumulative_mileage, buffer, bufferOffset);
    // Serialize message field [odo_fb_accumulative_angular]
    bufferOffset = _serializer.float32(obj.odo_fb_accumulative_angular, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type odo_fb
    let len;
    let data = new odo_fb(null);
    // Deserialize message field [odo_fb_accumulative_mileage]
    data.odo_fb_accumulative_mileage = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [odo_fb_accumulative_angular]
    data.odo_fb_accumulative_angular = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'date_handle/odo_fb';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '1f2b11cdb6b794cf8847471608f0a5ec';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float32  odo_fb_accumulative_mileage
    float32  odo_fb_accumulative_angular
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new odo_fb(null);
    if (msg.odo_fb_accumulative_mileage !== undefined) {
      resolved.odo_fb_accumulative_mileage = msg.odo_fb_accumulative_mileage;
    }
    else {
      resolved.odo_fb_accumulative_mileage = 0.0
    }

    if (msg.odo_fb_accumulative_angular !== undefined) {
      resolved.odo_fb_accumulative_angular = msg.odo_fb_accumulative_angular;
    }
    else {
      resolved.odo_fb_accumulative_angular = 0.0
    }

    return resolved;
    }
};

module.exports = odo_fb;
